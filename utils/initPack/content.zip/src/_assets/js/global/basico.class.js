const Basico = {
	init: function() {

	}
};

Basico.init();